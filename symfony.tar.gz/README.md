## You've got the Code for Joyful Development with Symfony 3. Yeehaw!

Hi there! Inside this code download you'll find the following things:

* A `start/` directory: how the project looked at the *start* of the tutorial

* A `finish/` directory: how the project looked after we did all the cool coding

In each directory, you'll find more details about how to setup the project.
But if you have any questions, just post a comment on the course page and
ask!